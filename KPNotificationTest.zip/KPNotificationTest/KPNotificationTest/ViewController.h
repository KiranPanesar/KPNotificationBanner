//
//  ViewController.h
//  KPNotificationTest
//
//  Created by Kiran Panesar on 04/06/2012.
//  Copyright (c) 2012 adappt Designs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

-(IBAction)showErrorMessage:(id)sender;
-(IBAction)showSuccessMessage:(id)sender;

@end
