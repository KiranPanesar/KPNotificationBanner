//
//  KPNotificationTestTests.h
//  KPNotificationTestTests
//
//  Created by Kiran Panesar on 04/06/2012.
//  Copyright (c) 2012 adappt Designs. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface KPNotificationTestTests : SenTestCase

@end
