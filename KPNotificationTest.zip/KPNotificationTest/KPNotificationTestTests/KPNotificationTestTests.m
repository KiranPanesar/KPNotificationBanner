//
//  KPNotificationTestTests.m
//  KPNotificationTestTests
//
//  Created by Kiran Panesar on 04/06/2012.
//  Copyright (c) 2012 adappt Designs. All rights reserved.
//

#import "KPNotificationTestTests.h"

@implementation KPNotificationTestTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in KPNotificationTestTests");
}

@end
